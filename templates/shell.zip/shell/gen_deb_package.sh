#!/bin/bash
###############################################################################
# NOME: gen_deb_package.sh
# DESCRIÇÃO: Automatiza a criação de um pacote instalador .deb para sistemas
#            baseados em Debian/Ubuntu, salvando na pasta build/.
###############################################################################

PROJECT_NAME="parcel-python"
VERSION="1.0.0"
DEB_ROOT="/tmp/${PROJECT_NAME}_deb"
OUTPUT_DIR="./build"

echo "📦 Iniciando empacotamento .deb..."

mkdir -p "$OUTPUT_DIR"
rm -rf "$DEB_ROOT"
mkdir -p "$DEB_ROOT/usr/bin"
mkdir -p "$DEB_ROOT/usr/share/applications"
mkdir -p "$DEB_ROOT/DEBIAN"

# Copia script principal ou cria executável empacotado
mkdir -p "$DEB_ROOT/usr/share/parcel-python"
cp -r . "$DEB_ROOT/usr/share/parcel-python/" 2>/dev/null || true

cat << 'LAUNCHER' > "$DEB_ROOT/usr/bin/parcel-python"
#!/bin/bash
cd /usr/share/parcel-python
exec python3 -m parcel.main "$@"
LAUNCHER
chmod +x "$DEB_ROOT/usr/bin/parcel-python"

# Gera arquivo de controle
cat << CONTROL > "$DEB_ROOT/DEBIAN/control"
Package: $PROJECT_NAME
Version: $VERSION
Section: utils
Priority: optional
Architecture: all
Maintainer: Marcel Aparecido de Andrade <marcel@parcel.com>
Description: Parcel-Python IDE - AI-Driven Industrial Development Toolkit.
CONTROL

dpkg-deb --build "$DEB_ROOT" "$OUTPUT_DIR/${PROJECT_NAME}_${VERSION}.deb"

echo "✅ Sucesso! Instalador gerado em: $OUTPUT_DIR/${PROJECT_NAME}_${VERSION}.deb"
