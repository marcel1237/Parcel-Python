#!/bin/bash
###############################################################################
# NOME: release_packager.sh
# DESCRIÇÃO: Automatiza o empacotamento do Parcel-Python para release (.tar.gz).
###############################################################################

VERSION=${1:-"v1.0.0"}
PROJECT_NAME="Parcel_Python"
OUTPUT_DIR="./build"
OUT_NAME="${OUTPUT_DIR}/${PROJECT_NAME}_${VERSION}_linux_x64.tar.gz"

echo "Preparando Release $VERSION para Parcel-Python..."

mkdir -p "$OUTPUT_DIR"

echo "Empacotando código e recursos..."
tar -czf "$OUT_NAME" \
    --exclude="build" \
    --exclude=".git" \
    --exclude=".parcel_backups.db" \
    --exclude="venv" \
    .

echo "--- RELEASE CONCLUÍDA ---"
echo "Arquivo gerado: $OUT_NAME"
