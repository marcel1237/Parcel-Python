#!/bin/bash
###############################################################################
# NOME: gen_rpm_package.sh
# DESCRIÇÃO: Automatiza a criação de um pacote .rpm salvando na pasta build/.
###############################################################################

PROJECT_NAME="parcel-python"
VERSION="1.0.0"
RPM_ROOT="$HOME/rpmbuild"
OUTPUT_DIR="./build"

echo "📦 Iniciando construção do pacote .rpm..."

mkdir -p "$OUTPUT_DIR"
mkdir -p "$RPM_ROOT"/{BUILD,RPMS,SOURCES,SPECS,SRPMS}

cat << SPEC > "$RPM_ROOT/SPECS/${PROJECT_NAME}.spec"
Name:           ${PROJECT_NAME}
Version:        ${VERSION}
Release:        1%{?dist}
Summary:        Parcel-Python IDE - AI-Driven Industrial Development Toolkit.
License:        Proprietary
URL:            https://github.com/parcel/parcel-python

%description
AI-Driven Industrial Development Toolkit built on PyQt6 and Python 3.10+.

%install
mkdir -p %{buildroot}/usr/share/parcel-python
cp -r $(pwd)/* %{buildroot}/usr/share/parcel-python/
mkdir -p %{buildroot}/usr/bin
cat << 'EOF' > %{buildroot}/usr/bin/parcel-python
#!/bin/bash
cd /usr/share/parcel-python
exec python3 -m parcel.main "\$@"
EOF
chmod +x %{buildroot}/usr/bin/parcel-python

%files
/usr/bin/parcel-python
/usr/share/parcel-python

%changelog
* $(date +"%a %b %d %Y") Marcel Aparecido de Andrade <marcel@parcel.com> - 1.0.0
- Initial RPM release.
SPEC

rpmbuild -ba "$RPM_ROOT/SPECS/${PROJECT_NAME}.spec"
find "$RPM_ROOT/RPMS" -name "*.rpm" -exec cp {} "$OUTPUT_DIR/" \;

echo "✅ Sucesso! Pacote RPM gerado na pasta build/"
