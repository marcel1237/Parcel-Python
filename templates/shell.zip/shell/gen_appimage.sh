#!/bin/bash
###############################################################################
# NOME: gen_appimage.sh
# DESCRIÇÃO: Automatiza a criação de um AppImage universal salvando na pasta build/.
###############################################################################

PROJECT_NAME="Parcel_Python"
VERSION="1.0.0"
APPDIR="/tmp/${PROJECT_NAME}.AppDir"
OUTPUT_DIR="./build"
ICON_PATH="./resources/parcel-python-dark.png"

echo "🚀 Iniciando criação do AppImage..."

mkdir -p "$OUTPUT_DIR"
rm -rf "$APPDIR"
mkdir -p "$APPDIR/usr/bin"
mkdir -p "$APPDIR/usr/share/icons/hicolor/256x256/apps"

# Copia código do projeto
mkdir -p "$APPDIR/usr/share/parcel-python"
cp -r . "$APPDIR/usr/share/parcel-python/" 2>/dev/null || true

cat << 'LAUNCHER' > "$APPDIR/usr/bin/parcel-python"
#!/bin/bash
cd /usr/share/parcel-python
exec python3 -m parcel.main "$@"
LAUNCHER
chmod +x "$APPDIR/usr/bin/parcel-python"

# Ícone
if [ -f "$ICON_PATH" ]; then
    cp "$ICON_PATH" "$APPDIR/parcel-python.png"
    cp "$ICON_PATH" "$APPDIR/usr/share/icons/hicolor/256x256/apps/parcel-python.png"
fi

# .desktop
cat << DESKTOP > "$APPDIR/parcel-python.desktop"
[Desktop Entry]
Name=Parcel-Python
Exec=parcel-python
Icon=parcel-python
Type=Application
Categories=Development;IDE;
Terminal=false
DESKTOP

# AppRun
cat << 'APPRUN' > "$APPDIR/AppRun"
#!/bin/sh
HERE="$(dirname "$(readlink -f "${0}")")"
export PATH="${HERE}/usr/bin/:${PATH}"
export LD_LIBRARY_PATH="${HERE}/usr/lib/:${LD_LIBRARY_PATH}"
exec parcel-python "$@"
APPRUN
chmod +x "$APPDIR/AppRun"

if command -v appimagetool > /dev/null; then
    appimagetool "$APPDIR" "$OUTPUT_DIR/${PROJECT_NAME}-${VERSION}-x86_64.AppImage"
    echo "✅ Sucesso! AppImage gerado em: $OUTPUT_DIR/${PROJECT_NAME}-${VERSION}-x86_64.AppImage"
else
    echo "⚠️ appimagetool não encontrado no PATH. AppDir preparado em $APPDIR."
fi
