#!/bin/bash
###############################################################################
# NOME: gen_suse_package.sh
# DESCRIÇÃO: Gera pacote openSUSE para o Parcel-Python, salvando na pasta build/.
###############################################################################

PROJECT_NAME="parcel-python-suse"
VERSION="1.0.0"
OUTPUT_DIR="./build"
SPEC_FILE="/tmp/${PROJECT_NAME}.spec"

echo "🦎 Preparando pacote especializado para OpenSUSE..."

mkdir -p "$OUTPUT_DIR"

cat << SPEC > "$SPEC_FILE"
Name:           ${PROJECT_NAME}
Version:        ${VERSION}
Release:        0
Summary:        Parcel-Python IDE - AI-Driven Industrial Development Toolkit.
License:        Proprietary
Group:          Development/Tools/IDE
BuildRequires:  python3, python3-PyQt6

%description
Parcel-Python IDE optimized for openSUSE.

%install
mkdir -p %{buildroot}/usr/share/parcel-python
cp -r $(pwd)/* %{buildroot}/usr/share/parcel-python/
mkdir -p %{buildroot}/usr/bin
cat << 'EOF' > %{buildroot}/usr/bin/parcel-python
#!/bin/bash
cd /usr/share/parcel-python
exec python3 -m parcel.main "\$@"
EOF
chmod +x %{buildroot}/usr/bin/parcel-python

%files
/usr/bin/parcel-python
/usr/share/parcel-python

%changelog
SPEC

echo "✅ Spec para SUSE gerada em: $SPEC_FILE"
